package br.edu.loja.servlet;
import br.edu.loja.repository.ProdutoRepository;
import javax.servlet.*;import javax.servlet.annotation.WebServlet;import javax.servlet.http.*;import java.io.IOException;
@WebServlet("/produtos")
public class ProdutosServlet extends HttpServlet {
 @Override protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{req.setAttribute("produtos",ProdutoRepository.listar());req.getRequestDispatcher("/WEB-INF/views/produtos.jsp").forward(req,resp);}
}
