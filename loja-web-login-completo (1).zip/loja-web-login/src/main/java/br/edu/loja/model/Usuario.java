package br.edu.loja.model;
import java.io.Serializable;
public class Usuario implements Serializable {
 private final String nome, email;
 public Usuario(String nome,String email){this.nome=nome;this.email=email;}
 public String getNome(){return nome;}
 public String getEmail(){return email;}
}
