package br.edu.loja.servlet;
import br.edu.loja.model.Usuario;
import br.edu.loja.repository.UsuarioMemoriaRepository;
import javax.servlet.*;import javax.servlet.annotation.WebServlet;import javax.servlet.http.*;import java.io.IOException;
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
 private final UsuarioMemoriaRepository repository=new UsuarioMemoriaRepository();
 @Override protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req,resp);}
 @Override protected void doPost(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{
 req.setCharacterEncoding("UTF-8");Usuario usuario=repository.autenticar(req.getParameter("email"),req.getParameter("senha"));
 if(usuario==null){req.setAttribute("erro","E-mail ou senha inválida.");req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req,resp);return;}
 HttpSession antiga=req.getSession(false);if(antiga!=null)antiga.invalidate();HttpSession sessao=req.getSession(true);sessao.setAttribute("usuarioLogado",usuario);resp.sendRedirect(req.getContextPath()+"/");
 }
}
