package br.edu.loja.servlet;
import javax.servlet.annotation.WebServlet;import javax.servlet.http.*;import java.io.IOException;
@WebServlet("/logout")
public class LogoutServlet extends HttpServlet {
 @Override protected void doPost(HttpServletRequest req,HttpServletResponse resp)throws IOException{HttpSession sessao=req.getSession(false);if(sessao!=null)sessao.invalidate();resp.sendRedirect(req.getContextPath()+"/");}
}
