package br.edu.loja.servlet;
import br.edu.loja.model.Produto;import br.edu.loja.repository.ProdutoRepository;
import javax.servlet.*;import javax.servlet.annotation.WebServlet;import javax.servlet.http.*;import java.io.IOException;import java.util.*;
@WebServlet(urlPatterns={"/carrinho","/carrinho/itens"})
public class CarrinhoServlet extends HttpServlet {
 @SuppressWarnings("unchecked") private List<Produto> carrinho(HttpSession sessao){List<Produto> itens=(List<Produto>)sessao.getAttribute("carrinho");if(itens==null){itens=new ArrayList<>();sessao.setAttribute("carrinho",itens);}return itens;}
 @Override protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{HttpSession sessao=req.getSession(false);req.setAttribute("itens",sessao==null?Collections.emptyList():carrinho(sessao));req.getRequestDispatcher("/WEB-INF/views/carrinho.jsp").forward(req,resp);}
 @Override protected void doPost(HttpServletRequest req,HttpServletResponse resp)throws IOException{try{Produto produto=ProdutoRepository.buscar(Integer.parseInt(req.getParameter("id")));if(produto!=null)carrinho(req.getSession()).add(produto);}catch(NumberFormatException e){resp.sendError(400,"ID inválido");return;}resp.sendRedirect(req.getContextPath()+"/carrinho");}
 @Override protected void doDelete(HttpServletRequest req,HttpServletResponse resp)throws IOException{HttpSession sessao=req.getSession(false);if(sessao==null){resp.setStatus(204);return;}if(req.getServletPath().equals("/carrinho/itens")){try{int id=Integer.parseInt(req.getParameter("id"));carrinho(sessao).removeIf(p->p.getId()==id);}catch(NumberFormatException e){resp.sendError(400,"ID inválido");return;}}else{sessao.removeAttribute("carrinho");}resp.setStatus(204);}
}
