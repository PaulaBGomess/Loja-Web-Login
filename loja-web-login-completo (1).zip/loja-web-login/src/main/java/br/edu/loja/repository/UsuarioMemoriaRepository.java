package br.edu.loja.repository;
import br.edu.loja.model.Usuario;
import java.util.HashMap;
import java.util.Map;
public class UsuarioMemoriaRepository {
 private static final Map<String,String> SENHAS = new HashMap<>();
 private static final Map<String,Usuario> USUARIOS = new HashMap<>();
 static { cadastrar("ana@loja.com","123456","Ana Beatriz Santos"); cadastrar("carlos@loja.com","123456","Carlos Lima"); }
 private static void cadastrar(String email,String senha,String nome){SENHAS.put(email,senha);USUARIOS.put(email,new Usuario(nome,email));}
 public Usuario autenticar(String email,String senha){if(email==null||senha==null)return null;String chave=email.trim().toLowerCase(java.util.Locale.ROOT);return senha.equals(SENHAS.get(chave))?USUARIOS.get(chave):null;}
}
