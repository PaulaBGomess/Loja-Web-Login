package br.edu.loja.repository;
import br.edu.loja.model.Produto;
import java.util.*;
public class ProdutoRepository {
 private static final List<Produto> PRODUTOS=Collections.unmodifiableList(Arrays.asList(new Produto(1,"Notebook",3500),new Produto(2,"Mouse",79.90),new Produto(3,"Teclado Mecânico",249.90),new Produto(4,"Monitor",899.90)));
 public static List<Produto> listar(){return PRODUTOS;}
 public static Produto buscar(int id){for(Produto p:PRODUTOS)if(p.getId()==id)return p;return null;}
}
