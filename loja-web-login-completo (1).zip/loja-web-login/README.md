# Loja Web — Login com HttpSession

Atividade de Programação para Web I. Java Servlet 4 (`javax.servlet`), JSP, EL, DAO em memória, sessão, forward, redirect, produtos e carrinho.

## Executar

1. Instale JDK 8+ e Maven.
2. Execute `mvn clean package` na raiz do projeto.
3. Copie `target/loja-web.war` para `webapps/` do Apache Tomcat 9.
4. Acesse `http://localhost:8080/loja-web/`.

## Credenciais de demonstração

- `ana@loja.com` / `123456` — Ana Beatriz Santos
- `carlos@loja.com` / `123456` — Carlos Lima

**Aviso:** as senhas estão em texto simples exclusivamente para demonstração acadêmica; nunca use esse modelo em produção.

## Rotas

- `GET /` — início com nome do usuário logado, se houver.
- `GET /login` — forward para `/WEB-INF/views/login.jsp`.
- `POST /login` — valida credenciais, registra `usuarioLogado` na sessão e redireciona.
- `POST /logout` — invalida sessão e redireciona ao início.
- `GET /produtos` — catálogo.
- `GET /carrinho` — carrinho da sessão.
- `POST /carrinho?id=2` — adiciona produto.
- `DELETE /carrinho/itens?id=2` — remove itens de mesmo ID.
- `DELETE /carrinho` — limpa carrinho.

## Testes sugeridos

1. Acessar `/login`: não deve aparecer mensagem de erro.
2. Tentar senha errada: mensagem deve aparecer sem alterar autenticação.
3. Entrar com Ana: página inicial deve exibir `Olá, Ana Beatriz Santos!`.
4. Navegar por produtos/carrinho e voltar: nome continua visível.
5. Adicionar produtos ao carrinho; testar remoção e limpeza.
6. Abrir janela anônima: usuário não estará autenticado.
7. Clicar em Sair: a sessão é invalidada e o botão Entrar volta a aparecer.

## Observação

O ZIP recebido (`loja-web-main.zip`) continha apenas README.md. Esta é uma implementação independente; para preservar exatamente o projeto anterior, envie o ZIP completo com `src`, `pom.xml` e `assets`.
