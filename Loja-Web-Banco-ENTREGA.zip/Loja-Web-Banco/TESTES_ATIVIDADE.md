# Roteiro de verificação

1. Abra a loja e clique em **Produtos**. O catálogo deve mostrar cinco produtos.
2. Adicione Mouse duas vezes e Teclado Mecânico uma vez. O carrinho deve mostrar três unidades e total de R$ 410,00. Atualize a página e confira o contador também no catálogo.
3. Abra a loja em janela anônima. O carrinho de visitante deve estar vazio nessa janela e manter os itens na janela anterior.
4. Na janela anterior, clique em **Remover** ao lado do Mouse. Devem restar um item e total de R$ 250,00. Clique em **Limpar carrinho** e confira a mensagem de carrinho vazio.
5. Tente entrar com senha incorreta. O formulário deve exibir a mensagem de erro. Entre com `ana@loja.com` e senha `123456`. A página inicial deve mostrar “Olá, Ana Beatriz Santos!”.
6. Com Ana logada, adicione Monitor e clique em **Sair**. Entre com Carlos e confira que o Monitor de Ana não aparece.
7. Reinicie o Tomcat e entre novamente com Ana usando o mesmo banco. O Monitor deve continuar no carrinho. Remova-o ou use **Limpar carrinho** para restaurar o estado de teste.
