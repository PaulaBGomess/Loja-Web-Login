# Loja Web com uso de banco de dados

Atividade de Programação para Web I. A aplicação original foi adaptada para persistir produtos, usuários e itens do carrinho em um banco relacional H2 em arquivo. O projeto mantém Servlets 4.0, JSP, JSTL, HttpSession e empacotamento Maven em WAR.

## Executar no Windows com PowerShell

Pré-requisitos: JDK 11 ou superior, Maven no PATH e Apache Tomcat **9** extraído. Abra o PowerShell na pasta que contém o `pom.xml`.

```powershell
mvn clean package
```

Com a compilação concluída, ajuste o caminho do Tomcat no comando abaixo. Execute com o servidor parado e mantenha o terminal aberto enquanto usa a loja.

```powershell
$tomcat = 'C:\caminho\apache-tomcat-9.0.113'
Copy-Item .\target\loja-web-banco.war (Join-Path $tomcat 'webapps\loja-web-banco.war') -Force
& (Join-Path $tomcat 'bin\catalina.bat') run
```

Abra [http://localhost:8080/loja-web-banco/](http://localhost:8080/loja-web-banco/).

## Executar no GitHub Codespaces

1. Envie o conteúdo da pasta `Loja-Web-Banco` para a raiz do repositório público que vai entregar. Inclua a pasta oculta `.devcontainer`.
2. No GitHub, abra **Code → Codespaces → Create codespace on main**.
3. No terminal do Codespace, rode `bash iniciar-codespaces.sh`. O script compila o WAR e inicia o Tomcat 9 na porta 8080.
4. Na aba **Ports**, clique com o botão direito na porta 8080 e escolha **Port Visibility → Public**. Copie a URL encaminhada, acrescente `/loja-web-banco/` e abra em uma janela anônima para verificar o acesso.
5. Entregue o ZIP, o link do repositório e o link da aplicação. Deixe o Codespace ativo para a avaliação.

[Documentação do GitHub sobre encaminhamento de portas](https://docs.github.com/pt/codespaces/developing-in-a-codespace/forwarding-ports-in-your-codespace)

## Banco e contas de demonstração

Na primeira execução, o script `src/main/resources/banco.sql` cria as tabelas `produtos`, `usuarios` e `carrinho_itens` e insere os registros iniciais. A inicialização pode ser repetida sem substituir os registros existentes. As senhas de teste são armazenadas como hashes PBKDF2 com salt individual.

| Conta | Senha de teste |
| --- | --- |
| `ana@loja.com` | `123456` |
| `carlos@loja.com` | `123456` |

O banco fica em `~/.loja-web-banco/loja.mv.db` por padrão. No Codespaces, o script usa `.dados/loja.mv.db` no projeto. A localização pode ser configurada com a propriedade Java `-Dloja.dados=/caminho/para/pasta`. O H2 roda dentro da aplicação e dispensa a instalação de um servidor de banco separado.

A sessão identifica a conta logada ou o carrinho de visitante. Os itens ficam no banco. O carrinho de visitante dura até o fim da sessão e é descartado ao fazer login. O carrinho da conta reaparece após sair e entrar novamente, inclusive após reiniciar o servidor usando o mesmo arquivo de banco.

## Rotas

| Método | Rota | Resultado |
| --- | --- | --- |
| GET | `/` | Página inicial e saudação quando há login |
| GET | `/produtos` | Catálogo consultado no banco |
| GET | `/carrinho` | Itens, quantidades, subtotais e total |
| POST | `/carrinho/itens` | Adiciona ou incrementa o produto enviado no campo `id` |
| DELETE | `/carrinho/itens?id=2` | Remove o produto do carrinho atual |
| DELETE | `/carrinho` | Limpa o carrinho atual |
| GET | `/login` | Formulário de login |
| POST | `/login` | Confere usuário e senha e abre a sessão |
| POST | `/logout` | Encerra a sessão e volta à página inicial |

Consulte [TESTES_ATIVIDADE.md](TESTES_ATIVIDADE.md) para o roteiro de verificação.
