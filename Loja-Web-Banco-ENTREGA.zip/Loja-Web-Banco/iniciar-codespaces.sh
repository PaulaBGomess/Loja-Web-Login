#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"

tomcat_versao=9.0.113
tomcat_dir="$PWD/.runtime/apache-tomcat-$tomcat_versao"
arquivo="$PWD/.runtime/tomcat-$tomcat_versao.tar.gz"

mvn -B package

if [[ ! -x "$tomcat_dir/bin/catalina.sh" ]]; then
    mkdir -p .runtime
    curl --fail --location --silent --show-error --retry 3 \
        "https://repo.maven.apache.org/maven2/org/apache/tomcat/tomcat/$tomcat_versao/tomcat-$tomcat_versao.tar.gz" \
        --output "$arquivo"
    tar -xzf "$arquivo" -C .runtime
    rm "$arquivo"
fi

cp target/loja-web-banco.war "$tomcat_dir/webapps/"
export CATALINA_OPTS="${CATALINA_OPTS:-} -Dloja.dados=.dados"
exec "$tomcat_dir/bin/catalina.sh" run
