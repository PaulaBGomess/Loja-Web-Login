package br.edu.ifto.web.dao;

import br.edu.ifto.web.model.Usuario;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Locale;

public class UsuarioRepository {
    public Usuario autenticar(String email, String senha) throws SQLException {
        if (email == null || senha == null || senha.length() > 256) {
            return null;
        }
        try (Connection conexao = Banco.conectar();
             PreparedStatement consulta = conexao.prepareStatement(
                     "SELECT nome, email, senha_salt, senha_hash FROM usuarios WHERE email = ?")) {
            consulta.setString(1, email.trim().toLowerCase(Locale.ROOT));
            try (ResultSet resultado = consulta.executeQuery()) {
                if (resultado.next() && senhaValida(senha, resultado.getString("senha_salt"),
                        resultado.getString("senha_hash"))) {
                    return new Usuario(resultado.getString("nome"), resultado.getString("email"));
                }
                return null;
            }
        }
    }

    private boolean senhaValida(String senha, String salt, String hash) {
        PBEKeySpec especificacao = new PBEKeySpec(senha.toCharArray(), bytesHex(salt), 600_000, 256);
        try {
            byte[] calculado = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(especificacao).getEncoded();
            return MessageDigest.isEqual(calculado, bytesHex(hash));
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("Falha ao verificar a senha.", e);
        } finally {
            especificacao.clearPassword();
        }
    }

    private byte[] bytesHex(String texto) {
        byte[] bytes = new byte[texto.length() / 2];
        for (int i = 0; i < bytes.length; i++) {
            bytes[i] = (byte) Integer.parseInt(texto.substring(i * 2, i * 2 + 2), 16);
        }
        return bytes;
    }
}
