package br.edu.ifto.web.servlet;

import br.edu.ifto.web.dao.CarrinhoRepository;
import br.edu.ifto.web.model.Usuario;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
import java.sql.SQLException;
import java.util.UUID;

@WebListener
public class CarrinhoSessao implements HttpSessionListener {
    private static final String ATRIBUTO = "chaveCarrinhoVisitante";

    static String chave(HttpSession sessao, boolean criar) {
        if (sessao == null) {
            return null;
        }
        synchronized (sessao) {
            Usuario usuario = (Usuario) sessao.getAttribute("usuarioLogado");
            if (usuario != null) {
                return "conta:" + usuario.getEmail();
            }
            String visitante = (String) sessao.getAttribute(ATRIBUTO);
            if (visitante == null && criar) {
                visitante = "visitante:" + UUID.randomUUID();
                sessao.setAttribute(ATRIBUTO, visitante);
            }
            return visitante;
        }
    }

    @Override
    public void sessionDestroyed(HttpSessionEvent evento) {
        HttpSession sessao = evento.getSession();
        String visitante = (String) sessao.getAttribute(ATRIBUTO);
        try {
            new CarrinhoRepository().limpar(visitante);
        } catch (SQLException e) {
            sessao.getServletContext().log("Falha ao limpar o carrinho do visitante.", e);
        }
    }
}
