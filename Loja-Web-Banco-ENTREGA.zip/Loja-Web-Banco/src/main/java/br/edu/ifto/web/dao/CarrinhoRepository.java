package br.edu.ifto.web.dao;

import br.edu.ifto.web.model.ItemCarrinho;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CarrinhoRepository {
    public List<ItemCarrinho> listar(String chave) throws SQLException {
        List<ItemCarrinho> itens = new ArrayList<>();
        if (chave == null) {
            return itens;
        }
        String sql = "SELECT p.id, p.nome, p.descricao, p.preco, i.quantidade "
                + "FROM carrinho_itens i JOIN produtos p ON p.id = i.produto_id "
                + "WHERE i.carrinho = ? ORDER BY p.id";
        try (Connection conexao = Banco.conectar();
             PreparedStatement consulta = conexao.prepareStatement(sql)) {
            consulta.setString(1, chave);
            try (ResultSet resultado = consulta.executeQuery()) {
                while (resultado.next()) {
                    itens.add(new ItemCarrinho(ProdutoRepository.lerProduto(resultado),
                            resultado.getInt("quantidade")));
                }
            }
        }
        return itens;
    }

    public boolean adicionar(String chave, int produtoId) throws SQLException {
        String sql = "INSERT INTO carrinho_itens (carrinho, produto_id, quantidade) "
                + "SELECT ?, id, 1 FROM produtos WHERE id = ? "
                + "ON DUPLICATE KEY UPDATE quantidade = quantidade + 1";
        try (Connection conexao = Banco.conectar();
             PreparedStatement comando = conexao.prepareStatement(sql)) {
            comando.setString(1, chave);
            comando.setInt(2, produtoId);
            return comando.executeUpdate() > 0;
        }
    }

    public void remover(String chave, int produtoId) throws SQLException {
        if (chave == null) {
            return;
        }
        try (Connection conexao = Banco.conectar();
             PreparedStatement comando = conexao.prepareStatement(
                     "DELETE FROM carrinho_itens WHERE carrinho = ? AND produto_id = ?")) {
            comando.setString(1, chave);
            comando.setInt(2, produtoId);
            comando.executeUpdate();
        }
    }

    public void limpar(String chave) throws SQLException {
        if (chave == null) {
            return;
        }
        try (Connection conexao = Banco.conectar();
             PreparedStatement comando = conexao.prepareStatement(
                     "DELETE FROM carrinho_itens WHERE carrinho = ?")) {
            comando.setString(1, chave);
            comando.executeUpdate();
        }
    }
}
