package br.edu.ifto.web.dao;

import org.h2.tools.RunScript;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

@WebListener
public class Banco implements ServletContextListener {
    private static final Path DIRETORIO = Path.of(System.getProperty(
            "loja.dados", Path.of(System.getProperty("user.home"), ".loja-web-banco").toString()))
            .toAbsolutePath().normalize();
    private static final String URL = "jdbc:h2:file:" + DIRETORIO.resolve("loja")
            + ";MODE=MySQL;DB_CLOSE_ON_EXIT=FALSE";

    @Override
    public void contextInitialized(ServletContextEvent evento) {
        try {
            Files.createDirectories(DIRETORIO);
            Class.forName("org.h2.Driver");
            try (Connection conexao = conectar();
                 InputStreamReader script = new InputStreamReader(
                         Banco.class.getResourceAsStream("/banco.sql"), StandardCharsets.UTF_8)) {
                RunScript.execute(conexao, script);
            }
        } catch (IOException | ClassNotFoundException | SQLException e) {
            throw new IllegalStateException("Falha ao inicializar o banco da loja.", e);
        }
    }

    static Connection conectar() throws SQLException {
        return DriverManager.getConnection(URL, "sa", "");
    }
}
