package br.edu.ifto.web.servlet;

import br.edu.ifto.web.dao.CarrinhoRepository;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/carrinho/itens")
public class CarrinhoItemServlet extends HttpServlet {
    private final CarrinhoRepository repository = new CarrinhoRepository();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        Integer id = lerId(request);
        if (id == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Id do produto inválido.");
            return;
        }
        try {
            if (!repository.adicionar(CarrinhoSessao.chave(request.getSession(), true), id)) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Produto não encontrado.");
                return;
            }
        } catch (SQLException e) {
            throw new ServletException("Falha ao adicionar produto ao carrinho.", e);
        }
        response.sendRedirect(request.getContextPath() + "/carrinho");
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        Integer id = lerId(request);
        if (id == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Id do produto inválido.");
            return;
        }
        try {
            repository.remover(CarrinhoSessao.chave(request.getSession(false), false), id);
        } catch (SQLException e) {
            throw new ServletException("Falha ao remover produto do carrinho.", e);
        }
        response.setStatus(HttpServletResponse.SC_NO_CONTENT);
    }

    private Integer lerId(HttpServletRequest request) {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            return id > 0 ? id : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
