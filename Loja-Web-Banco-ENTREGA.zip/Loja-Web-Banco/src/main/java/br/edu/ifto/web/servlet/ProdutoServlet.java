package br.edu.ifto.web.servlet;

import br.edu.ifto.web.dao.CarrinhoRepository;
import br.edu.ifto.web.dao.ProdutoRepository;
import br.edu.ifto.web.model.ItemCarrinho;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/produtos")
public class ProdutoServlet extends HttpServlet {
    private final ProdutoRepository produtos = new ProdutoRepository();
    private final CarrinhoRepository carrinho = new CarrinhoRepository();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            request.setAttribute("produtos", produtos.listarTodos());
            String chave = CarrinhoSessao.chave(request.getSession(false), false);
            request.setAttribute("quantidadeTotal",
                    carrinho.listar(chave).stream().mapToInt(ItemCarrinho::getQuantidade).sum());
        } catch (SQLException e) {
            throw new ServletException("Falha ao consultar os produtos.", e);
        }
        request.getRequestDispatcher("/WEB-INF/views/produtos.jsp").forward(request, response);
    }
}
