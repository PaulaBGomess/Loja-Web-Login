package br.edu.ifto.web.servlet;

import br.edu.ifto.web.dao.CarrinhoRepository;
import br.edu.ifto.web.model.ItemCarrinho;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/carrinho")
public class CarrinhoServlet extends HttpServlet {
    private final CarrinhoRepository repository = new CarrinhoRepository();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<ItemCarrinho> itens;
        try {
            itens = repository.listar(CarrinhoSessao.chave(request.getSession(false), false));
        } catch (SQLException e) {
            throw new ServletException("Falha ao consultar o carrinho.", e);
        }
        request.setAttribute("itensCarrinho", itens);
        request.setAttribute("quantidadeTotal", itens.stream().mapToInt(ItemCarrinho::getQuantidade).sum());
        request.setAttribute("valorTotal", itens.stream().map(ItemCarrinho::getSubtotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add));
        request.getRequestDispatcher("/WEB-INF/views/carrinho.jsp").forward(request, response);
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException {
        try {
            repository.limpar(CarrinhoSessao.chave(request.getSession(false), false));
        } catch (SQLException e) {
            throw new ServletException("Falha ao limpar o carrinho.", e);
        }
        response.setStatus(HttpServletResponse.SC_NO_CONTENT);
    }
}
