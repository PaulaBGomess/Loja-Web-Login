package br.edu.ifto.web.dao;

import br.edu.ifto.web.model.Produto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProdutoRepository {
    public List<Produto> listarTodos() throws SQLException {
        List<Produto> produtos = new ArrayList<>();
        try (Connection conexao = Banco.conectar();
             PreparedStatement consulta = conexao.prepareStatement(
                     "SELECT id, nome, descricao, preco FROM produtos ORDER BY id");
             ResultSet resultado = consulta.executeQuery()) {
            while (resultado.next()) {
                produtos.add(lerProduto(resultado));
            }
        }
        return produtos;
    }

    static Produto lerProduto(ResultSet resultado) throws SQLException {
        return new Produto(resultado.getInt("id"), resultado.getString("nome"),
                resultado.getString("descricao"), resultado.getBigDecimal("preco"));
    }
}
