CREATE TABLE IF NOT EXISTS produtos (
    id INTEGER PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao VARCHAR(255) NOT NULL,
    preco DECIMAL(12, 2) NOT NULL CHECK (preco >= 0)
);

CREATE TABLE IF NOT EXISTS usuarios (
    email VARCHAR(254) PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    senha_salt CHAR(32) NOT NULL,
    senha_hash CHAR(64) NOT NULL
);

CREATE TABLE IF NOT EXISTS carrinho_itens (
    carrinho VARCHAR(262) NOT NULL,
    produto_id INTEGER NOT NULL REFERENCES produtos(id),
    quantidade INTEGER NOT NULL CHECK (quantidade > 0),
    PRIMARY KEY (carrinho, produto_id)
);

INSERT IGNORE INTO produtos (id, nome, descricao, preco) VALUES
    (1, 'Notebook', 'Notebook para trabalho e estudos.', 3500.00),
    (2, 'Mouse', 'Mouse óptico USB.', 80.00),
    (3, 'Teclado Mecânico', 'Teclado mecânico para produtividade.', 250.00),
    (4, 'Monitor', 'Monitor para estação de trabalho.', 1200.00),
    (5, 'Headset', 'Headset para aulas e reuniões.', 180.00);

INSERT IGNORE INTO usuarios (email, nome, senha_salt, senha_hash) VALUES
    ('ana@loja.com', 'Ana Beatriz Santos', '28261ebb48481eb81c979821fb8da403', 'b06600fed72d4c5bb1459a909d4817e0005f2d8372fc328644e766dab74aa3d8'),
    ('carlos@loja.com', 'Carlos Lima', 'ed893d6e84f1e451eed6b09ace06883e', '22e8072d832f2ba716d9874ef58972d89a0cca9993025b8e0460604c4a4a2b9c');
